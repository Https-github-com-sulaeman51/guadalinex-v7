#!/bin/sh

export LD_PRELOAD=/usr/lib/libv4l/v4l1compat.so
effectv $1 $2 $3
