#!/usr/bin/env python
# -*- encoding: utf-8 -*-
#       effectv-wonder.py
#       
#       Copyright 2009 Álvaro Pinel Bueno <alvaropinel@gmail.com> and David Amián Valle <amialinux@gmail.com>
#
#       
#       This program is free software; you can redistribute it and/or modify
#       it under the terms of the GNU General Public License as published by
#       the Free Software Foundation; either version 2 of the License, or
#       (at your option) any later version.
#       
#       This program is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU General Public License for more details.
#       
#       You should have received a copy of the GNU General Public License
#       along with this program; if not, write to the Free Software
#       Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#       MA 02110-1301, USA.
#
#		####################
#		El origen del nombre
#
#		Lo más difícil de programar es, con diferencia, elegir un buen nombre para el programa. 
#		Puesto que partíamos del EffecTV (pronúnciese efectivi) era inevitable que a los de nuestra generación 
#		se nos ocurriera el sufijo -wonder. Y así seguro que a nadie se le olvida el nombre del programa.
#
#		Para los más jóvenes, el término efectivigüonder se puso de moda gracias a un esketch 
#		de los geniales Martes y Trece en el especial fin de año del 91. 
#		Parodiaban el famoso anuncio en el que Stevie Wonder decía aquello de “si bebes no conduzcas”. 
#		Y claro, un inofensivo “efectivamente” se convirtió en el gracioso “efectivigüonder” 
#		que de tanto repetirlo acabó por cansar.
#
#		####################

import pygtk
pygtk.require("2.0")
import gtk
import subprocess
import os

class Ewonder:
	def __init__(self):
		self.builder=gtk.Builder()
			
		#Take glade
		self.builder.add_from_file("/usr/share/effectv-wonder/effectv-wonder.glade")
		#Initial autoconetions
		self.builder.connect_signals(self)
		self.wdeffectv=self.builder.get_object("wdeffectv")
        	self.wdeffectv.set_title("Effectv-wonder")
       		self.wdeffectv.set_icon_from_file("/usr/share/pixmaps/effectv-wonder.png") 
		self.liststore=gtk.ListStore(str)
        	self.cbtype=self.builder.get_object("cbtype")
        	self.chkbtfullscreen=self.builder.get_object("chkbtfullscreen")
        	self.spbtscale=self.builder.get_object("spbtscale")
        	self.btaceptar=self.builder.get_object("btaceptar")
        	self.cell = gtk.CellRendererText()
        
        	self.cbtype.pack_start(self.cell)
        	self.cbtype.add_attribute(self.cell, 'text', 0)
        	self.cbtype.set_wrap_width(4)
		
		#Define different effects
        	self.liststore.append(['DumbTV'])
        	self.liststore.append(['QuarkTV'])
        	self.liststore.append(['FireTV'])
        	self.liststore.append(['BurningTV'])
       		self.liststore.append(['RadioacTV'])
        	self.liststore.append(['StreakTV'])
        	self.liststore.append(['BaltanTV'])
        	self.liststore.append(['1DTV'])
        	self.liststore.append(['DotTV'])
        	self.liststore.append(['MosaicTV'])
        	self.liststore.append(['PuzzleTV'])
        	self.liststore.append(['PredatorTV'])
        	self.liststore.append(['SpiralTV'])
        	self.liststore.append(['SimuraTV'])
        	self.liststore.append(['EdgeTV'])
        	self.liststore.append(['ShagadelicTV'])
        	self.liststore.append(['NoiseTV'])
        	self.liststore.append(['AgingTV'])
        	self.liststore.append(['TransFormTV'])
        	self.liststore.append(['LifeTV'])
        	self.liststore.append(['SparkTV'])
        	self.liststore.append(['warpTV'])
        	self.liststore.append(['HolographicTV'])
        	self.liststore.append(['cycleTV'])
        	self.liststore.append(['RippleTV'])
        	self.liststore.append(['DiceTV'])
        	self.liststore.append(['VertigoTV'])
        	self.liststore.append(['DeinterlaceTV'])
        	self.liststore.append(['NervousTV'])
        	self.liststore.append(['RndmTV'])
        	self.liststore.append(['RevTV'])
        	self.liststore.append(['RandomDotStereoTV'])
        	self.liststore.append(['lensTV'])
        	self.liststore.append(['DiffTV'])
        	self.liststore.append(['BrokenTV'])
        	self.liststore.append(['WarholTV'])
        	self.liststore.append(['MatrixTV'])
        	self.liststore.append(['PUPTV'])
        	self.liststore.append(['ChameleonTV'])
        	self.liststore.append(['OpTV'])
        	self.liststore.append(['NervousHalf'])
        	self.liststore.append(['SloFastTV'])
        	self.liststore.append(['DisplayWall'])
        	self.liststore.append(['BlueScreenTV'])
        	self.liststore.append(['ColourfulStreak'])
        	self.liststore.append(['TimeDistortion'])
        	self.liststore.append(['EdgeBlurTV'])
        	self.typeselect=None
        	
		self.cbtype.set_model(self.liststore)
        	self.cbtype.set_active(0)
        	self.wdeffectv.show_all()
          
    
	def on_wdeffectv_destroy(self, widget, data=None):
        	gtk.main_quit()        
        
        
    	def on_btaceptar_clicked(self, widget, data=None):
        	model=self.cbtype.get_model()
        	index=self.cbtype.get_active()
        	self.typeselect=model[index][0]
        
        	#Take de scale, if fullscreen desactivate scale
        	if self.chkbtfullscreen.get_active():
			self.scale=1
            
		else:
            		self.scale=self.spbtscale.get_value_as_int()
            		#Default scale 0 -> 1
            		if self.scale == 0:
                		self.scale=1
                
        	#Call effectv
		self.execute_efect()
        
	def on_chkbtfullscreen_toggled (self, widget, data=None):
		if widget.get_active():
			self.spbtscale.set_sensitive(False)
            
		else:
			self.spbtscale.set_sensitive(True)
            
	def execute_efect(self):
		self.cbtype.set_sensitive(False)
		self.spbtscale.set_sensitive(False)
		self.chkbtfullscreen.set_sensitive(False)
		self.btaceptar.set_sensitive(False)
        
		if self.chkbtfullscreen.get_active():
			self.res=subprocess.Popen(["sh", "/usr/share/effectv-wonder/effectv-wonder.sh", "-fullscreen", self.typeselect], stdout=subprocess.PIPE)
            
		else:
			self.res=subprocess.Popen(["sh", "/usr/share/effectv-wonder/effectv-wonder.sh", "-scale "+str(self.scale), self.typeselect], stdout=subprocess.PIPE)
            
	def main(self):
        	gtk.main()
        
if __name__ == "__main__":
    ewonder=Ewonder()
    ewonder.main()
