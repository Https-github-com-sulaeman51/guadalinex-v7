valac -g --thread --pkg=libsoup-2.4 --pkg=gtk+-2.0 --pkg=dbus-glib-1 \
    MeigaServer.vala Meiga.vala Rss.vala
